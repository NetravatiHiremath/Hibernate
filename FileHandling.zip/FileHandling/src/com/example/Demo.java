package com.example;


import java.io.File;
import java.io.FileReader;


public class Demo 
{
	public static void main(String[] args) throws Exception
	{


		File f = new File("C:\\Users\\91998\\Downloads\\Reader\\File.txt");
		FileReader fr = new FileReader(f);
		int i = fr.read();
		while(i!=-1)
		{
			System.out.print((char)i);
			i=fr.read();
		}
		fr.close();


	}
}
