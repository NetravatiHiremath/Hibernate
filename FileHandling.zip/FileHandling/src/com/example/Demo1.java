package com.example;

import java.io.File;

public class Demo1 
{
	public static void main(String[] args) 
	{
      File file = new File("C:\\Users\\91998\\Downloads\\Reader\\myfile.txt");
      
      
     boolean b = file.renameTo(new File("C:\\Users\\91998\\Downloads\\Directory/myfile.txt"));
     System.out.println("b"+"-->"+b);
     
	}
	
	/**
	 *  renameTo() is used to rename the file as well as to move the file
	 *  from one directory to another directory
	 *  renameTo() will always return the value in the form boolean results.
	 *  
	 */
}
