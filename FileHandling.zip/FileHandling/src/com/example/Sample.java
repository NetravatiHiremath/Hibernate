package com.example;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;

public class Sample {
	public static void main(String[] args) throws Exception {
//		String f = "file1//file2//file3//details.txt";
//
//		File file = new File(f);
//		if (!file.exists()) {
//			file.createNewFile();
//		}
		
		Path src=Path.of("/FileHandling/file1/file2/file3/details.txt");
		Path tar=Path.of("/FileHandling/file1/file2/");
		
		
		Files.move(src, tar,StandardCopyOption.REPLACE_EXISTING);
	}
}
